import React from 'react'

function Home() {
  return (
    <div className='home'>
        <div className='box1'>
        <div className='stand1'></div>
        <div className='stand2'></div>
        </div>
    </div>
  )
}

export default Home